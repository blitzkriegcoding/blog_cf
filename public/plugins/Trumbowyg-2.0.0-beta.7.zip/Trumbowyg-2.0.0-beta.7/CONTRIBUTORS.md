# Contributors

Trumbowyg is the result of many people who made translations or the code better.

- Alex-D
- lizardK
- VeeeneX
- Danny Hiemstra
- Nicolás Moncada
- Jan Svoboda
- Manfred62
- Nikola Trifunovic
- Vlad Radulescu
- foo9
- g2010a
- Adam Balogh
- Andreas Kohn
- Andrey Kogut
- Antoine Leblanc
- Christian
- Delvallée
- JoongSeob Vito Kim
- MIRK0
- Moisés Márquez
- Nathan Rosquist
- Paweł Abramowicz
- Ramiro Varandas Jr
- Rezha Julio
- Vinzgore
- Wisse Jelgersma
- abomokhahmed
- akai
- basteyy
- brentanalexander
- munzur
- teppokoivula
- udidoron
- Олег Ильин